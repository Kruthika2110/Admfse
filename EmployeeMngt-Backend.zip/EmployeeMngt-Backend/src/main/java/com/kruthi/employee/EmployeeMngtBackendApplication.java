package com.kruthi.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMngtBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMngtBackendApplication.class, args);
	}

}
