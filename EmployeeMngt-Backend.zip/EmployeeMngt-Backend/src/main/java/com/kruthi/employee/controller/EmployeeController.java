package com.kruthi.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kruthi.employee.model.Employee;
import com.kruthi.employee.repository.EmployeeRepository;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepo;
	
	//Read Operation
	//i.e getAll employee rows from table
	@GetMapping("/employees")
	public List<Employee> getAllEmployees()
	{
		return employeeRepo.findAll();
	}
	
	//create employee rest api, 
	//i.e create employee object to employee row in table
	@PostMapping("/employees")
	public Employee createEmployee(@RequestBody Employee employee)
	{
		return employeeRepo.save(employee);
		
	}
	
	//update employee rest api, 
	//i.e update employee object to employee row in table
	@PutMapping("/employees")
	public Employee updateEmployee(@RequestBody Employee employee)
	{
		return employeeRepo.save(employee);
	}
	
	//delete employee rest api,
	//i.e, delete employee object by id
	
	
}
