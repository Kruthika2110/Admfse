package com.kruthi.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kruthi.employee.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
